package com.workshop.day6.no12;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class No12Application {

	public static void main(String[] args) {
		SpringApplication.run(No12Application.class, args);
	}
	/*
	 * curl http://localhost:8080/api/users
	 */

	/*
	 * Insert
	 * curl -X POST -H "Content-Type: application/json" \
	 * -d '{"username":"Myat Zaw","email":"myatzaw@example.com"}' \
	 * http://localhost:8080/api/users
	 */

	/*
	 * Delete
	 * curl -X DELETE http://localhost:8080/api/users/1
	 */
}
