package com.workshop.day6.no14;

import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class No14Application {

	public static void main(String[] args) {
		SpringApplication.run(No14Application.class, args);
	}

	@Bean
	CommandLineRunner run(UserRepository userRepository) {
		return args -> {
			// Save sample users
			userRepository.save(new User("Alice", "alice@gmail.com"));
			userRepository.save(new User("Bob", "bob@yahoo.com"));
			userRepository.save(new User("Charlie", "charlie@gmail.com"));

			// Find users by domain
			String domain = "@gmail.com";
			List<User> gmailUsers = userRepository.findByEmailEndingWith(domain);

			System.out.println("Users with domain " + domain + ":");
			gmailUsers.forEach(System.out::println);
		};
	}
}
