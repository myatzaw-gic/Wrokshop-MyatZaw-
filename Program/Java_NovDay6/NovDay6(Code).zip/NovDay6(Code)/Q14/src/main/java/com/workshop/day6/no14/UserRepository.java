package com.workshop.day6.no14;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface UserRepository extends JpaRepository<User, Long> {

    // ✅ Find users by email domain
    List<User> findByEmailEndingWith(String domain);
}
