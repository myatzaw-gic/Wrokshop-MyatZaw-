package com.workshop.day6.no6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class No6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
