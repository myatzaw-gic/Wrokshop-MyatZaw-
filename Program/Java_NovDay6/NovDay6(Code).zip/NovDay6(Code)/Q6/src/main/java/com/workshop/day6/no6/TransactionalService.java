package com.workshop.day6.no6;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TransactionalService {

    private final UserRepository userRepository;

    public TransactionalService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Transactional
    public User saveUser(String name) {
        User user = new User();
        user.setName(name);
        return userRepository.save(user);
    }
}
