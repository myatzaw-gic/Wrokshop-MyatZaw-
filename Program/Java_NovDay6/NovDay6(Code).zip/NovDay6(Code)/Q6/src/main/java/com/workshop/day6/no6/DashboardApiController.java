package com.workshop.day6.no6;

import org.springframework.cache.CacheManager;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.concurrent.ExecutionException;

@RestController
public class DashboardApiController {

    private final CacheableService cacheableService;
    private final TransactionalService transactionalService;
    private final AsyncService asyncService;
    private final ScheduledService scheduledService;
    private final CacheManager cacheManager;

    public DashboardApiController(CacheableService cacheableService,
            TransactionalService transactionalService,
            AsyncService asyncService,
            ScheduledService scheduledService,
            CacheManager cacheManager) {
        this.cacheableService = cacheableService;
        this.transactionalService = transactionalService;
        this.asyncService = asyncService;
        this.scheduledService = scheduledService;
        this.cacheManager = cacheManager;
    }

    @GetMapping("/api/cacheable")
    public String triggerCacheable() {
        Long id = 1L;
        boolean isCached = cacheManager.getCache("users").get(id) != null;
        String user = cacheableService.getUser(id);
        return "User: " + user + " | Cached: " + isCached;
    }

    @GetMapping("/api/transactional")
    public String triggerTransactional() {
        return "Saved User: " + transactionalService.saveUser("Bob").getName();
    }

    @GetMapping("/api/async")
    public String triggerAsync() throws ExecutionException, InterruptedException {
        return asyncService.process("Async Job").get();
    }

    @GetMapping("/api/scheduled")
    public List<String> getScheduledLogs() {
        return scheduledService.getLogs();
    }
}
