package com.workshop.day6.no6;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service
public class ScheduledService {

    private final List<String> logs = new ArrayList<>();

    // Formatter for date & time
    private static final DateTimeFormatter FORMATTER
            = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    @Scheduled(fixedRate = 10000) // runs every 10 seconds
    public void logScheduled() {
        String timestamp = LocalDateTime.now().format(FORMATTER);
        String msg = "Scheduled task ran at " + timestamp;
        logs.add(msg);

        // Keep only the latest 5 logs
        if (logs.size() > 5) {
            logs.remove(0);
        }
    }

    public List<String> getLogs() {
        return new ArrayList<>(logs);
    }
}
