package com.workshop.day6.no6;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class CacheableService {

    @Cacheable("users")
    public String getUser(Long id) {
        simulateSlowCall();
        return "User " + id;
    }

    private void simulateSlowCall() {
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
