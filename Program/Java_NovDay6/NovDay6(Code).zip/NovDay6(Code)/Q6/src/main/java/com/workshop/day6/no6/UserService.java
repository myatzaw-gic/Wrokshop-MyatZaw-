package com.workshop.day6.no6;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Cacheable("users")
    public String getUser(Long id) {
        simulateSlowCall();
        return "User " + id;
    }

    private void simulateSlowCall() {
        try {
            Thread.sleep(3000);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
