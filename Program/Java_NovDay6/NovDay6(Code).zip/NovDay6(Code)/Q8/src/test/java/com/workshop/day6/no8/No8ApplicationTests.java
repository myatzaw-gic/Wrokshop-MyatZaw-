package com.workshop.day6.no8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class No8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
