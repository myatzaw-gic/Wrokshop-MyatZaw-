package com.workshop.day6.no8;

import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class UserService {

    private final UserRepository userRepository;

    // Constructor injection (best practice)
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // Business logic methods
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public User createUser(String name, String email) {
        // Example business logic: simple validation
        if (name == null || email == null) {
            throw new IllegalArgumentException("Name and email must not be null");
        }
        return userRepository.save(new User(name, email));
    }
}
