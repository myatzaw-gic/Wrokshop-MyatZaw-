package com.workshop.day6.no8;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    // GET all users
    @GetMapping
    public ResponseEntity<List<User>> getAllUsers() {
        List<User> users = userService.getAllUsers();
        return ResponseEntity.ok(users);
    }

    // POST JSON payload
    @PostMapping(consumes = "application/json")
    public ResponseEntity<User> addUserJson(@RequestBody User user) {
        User createdUser = userService.createUser(user.getName(), user.getEmail());
        return ResponseEntity.ok(createdUser);
    }

    // POST form data
    @PostMapping(consumes = "application/x-www-form-urlencoded")
    public ResponseEntity<User> addUserForm(@RequestParam String name, @RequestParam String email) {
        User createdUser = userService.createUser(name, email);
        return ResponseEntity.ok(createdUser);
    }
}
