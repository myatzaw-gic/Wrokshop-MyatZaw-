package com.workshop.day6.no8;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class No8Application {

    public static void main(String[] args) {
        SpringApplication.run(No8Application.class, args);
    }
    //http://localhost:8080/users
    /*  
	curl -X POST http://localhost:8080/users -H "Content-Type: application/json" -d '{"name":"Myat Zaw","email":"myatzaw@example.com"}'
     
    curl -X POST http://localhost:8080/users -H "Content-Type: application/x-www-form-urlencoded" -d "name=Myat Zaw&email=myatzaw@example.com"
     */
}
