package com.workshop.day6.no7;

import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    private final ProductService service;

    public ProductController(ProductService service) {
        this.service = service;
    }

    @PostMapping("/batch")
    public String batchInsert() {
        List<Product> list = new ArrayList<>();

        for (int i = 1; i <= 20000; i++) {
            list.add(new Product("Product " + i, BigDecimal.valueOf(i * 10)));
        }

        service.saveProductsInBatch(list);
        return "Batch Insert Completed!";
    }

    @GetMapping
    public List<Product> getAll() {
        return service.getAll();
    }
}