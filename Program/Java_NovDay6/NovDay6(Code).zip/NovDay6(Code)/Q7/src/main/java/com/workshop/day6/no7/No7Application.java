package com.workshop.day6.no7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class No7Application {

	public static void main(String[] args) {
		SpringApplication.run(No7Application.class, args);
	}
	// http://localhost:8080/api/products
	// POST http://localhost:8080/api/products/batch
}
