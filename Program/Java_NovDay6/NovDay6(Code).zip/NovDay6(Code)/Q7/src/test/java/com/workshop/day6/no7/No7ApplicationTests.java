package com.workshop.day6.no7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class No7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
