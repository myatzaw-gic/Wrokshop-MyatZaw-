package com.workshop.day6.no1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class No1Application {

	public static void main(String[] args) {
		SpringApplication.run(No1Application.class, args);
	}

	// http://localhost:8080/books

}
