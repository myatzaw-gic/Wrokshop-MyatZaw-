package com.workshop.day6.no1;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository // Optional, Spring will detect automatically
public interface BookRepository extends JpaRepository<Book, Long> {
    // You can define custom queries if needed
}
