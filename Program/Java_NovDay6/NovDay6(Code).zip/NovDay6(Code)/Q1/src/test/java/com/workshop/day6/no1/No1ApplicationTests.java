package com.workshop.day6.no1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class No1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
