package com.workshop.day6.no9;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class No9ApplicationTests {

	@Test
	void contextLoads() {
	}

}
