package com.workshop.day6.no9;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ProductController {

    private final ProductService service;

    public ProductController(ProductService service) {
        this.service = service;
    }

    @GetMapping("/products")
    public String products(
            @RequestParam(defaultValue = "0") String min,
            @RequestParam(defaultValue = "1000") String max,
            Model model) {
        model.addAttribute("products", service.getProductsInPriceRange(
                new java.math.BigDecimal(min),
                new java.math.BigDecimal(max)));
        return "products";
    }
}
