package com.workshop.day6.no9;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class No9Application {

	public static void main(String[] args) {
		SpringApplication.run(No9Application.class, args);
	}
	// http://localhost:8080/products
	// http://localhost:8080/products?min=100&max=500

}
