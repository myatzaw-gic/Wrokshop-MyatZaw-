package com.workshop.day6.no9;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import java.math.BigDecimal;
import java.util.List;

@Component
public class DataInitializer implements CommandLineRunner {

    private final ProductRepository repository;

    public DataInitializer(ProductRepository repository) {
        this.repository = repository;
    }

    @Override
    public void run(String... args) throws Exception {
        // Clear existing data
        repository.deleteAll();

        // Create sample products
        List<Product> products = List.of(
                createProduct("Laptop", new BigDecimal("1200")),
                createProduct("Smartphone", new BigDecimal("800")),
                createProduct("Headphones", new BigDecimal("150")),
                createProduct("Monitor", new BigDecimal("300")),
                createProduct("Keyboard", new BigDecimal("50")));

        // Save all at once
        repository.saveAll(products);

        System.out.println("Sample products initialized!");
    }

    private Product createProduct(String name, BigDecimal price) {
        Product product = new Product();
        product.setName(name);
        product.setPrice(price);
        return product;
    }
}
