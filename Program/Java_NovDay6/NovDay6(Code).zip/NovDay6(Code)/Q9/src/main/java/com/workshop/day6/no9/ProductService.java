package com.workshop.day6.no9;

import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class ProductService {

    private final ProductRepository repository;

    public ProductService(ProductRepository repository) {
        this.repository = repository;
    }

    public List<Product> getProductsInPriceRange(BigDecimal min, BigDecimal max) {
        return repository.findProductsInPriceRange(min, max);
    }
}
