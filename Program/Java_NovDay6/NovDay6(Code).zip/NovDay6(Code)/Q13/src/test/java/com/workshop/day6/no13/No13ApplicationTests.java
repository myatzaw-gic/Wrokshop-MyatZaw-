package com.workshop.day6.no13;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class No13ApplicationTests {

	@Test
	void contextLoads() {
	}

}
