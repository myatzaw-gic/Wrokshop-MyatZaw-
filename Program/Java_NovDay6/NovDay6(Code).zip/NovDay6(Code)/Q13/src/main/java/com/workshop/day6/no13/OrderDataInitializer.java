package com.workshop.day6.no13;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class OrderDataInitializer implements CommandLineRunner {

    private final OrderRepository orderRepository;

    public OrderDataInitializer(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        // Clear existing data
        orderRepository.deleteAll();

        // Preload sample orders
        List<Order> orders = List.of(
                new Order("Laptop", 2),
                new Order("Smartphone", 5),
                new Order("Headphones", 10),
                new Order("Monitor", 3),
                new Order("Keyboard", 7));

        // Save all orders
        orderRepository.saveAll(orders);

        System.out.println("Sample orders initialized!");
    }
}
