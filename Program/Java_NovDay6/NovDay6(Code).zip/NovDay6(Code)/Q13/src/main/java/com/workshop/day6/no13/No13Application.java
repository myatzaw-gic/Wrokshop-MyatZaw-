package com.workshop.day6.no13;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class No13Application {

	public static void main(String[] args) {
		SpringApplication.run(No13Application.class, args);
	}
	// curl http://localhost:8080/api/orders

	/*
	 * Insert
	 * curl -X POST -H "Content-Type: application/json" \
	 * -d '{"productName":"Tablet","quantity":4}' \
	 * http://localhost:8080/api/orders
	 * 
	 */
}