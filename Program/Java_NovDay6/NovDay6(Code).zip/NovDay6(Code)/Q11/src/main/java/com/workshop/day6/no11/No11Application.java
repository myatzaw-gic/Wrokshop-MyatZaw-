package com.workshop.day6.no11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class No11Application {

	public static void main(String[] args) {
		SpringApplication.run(No11Application.class, args);
	}

	// GET http://localhost:8080/api/users

}
