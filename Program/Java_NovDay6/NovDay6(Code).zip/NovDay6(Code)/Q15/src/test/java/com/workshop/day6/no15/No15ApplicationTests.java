package com.workshop.day6.no15;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class No15ApplicationTests {

	@Test
	void contextLoads() {
	}

}
