package com.workshop.day6.no15;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class No15Application {

    public static void main(String[] args) {
        SpringApplication.run(No15Application.class, args);
    }
    //http://localhost:8080/h2-console

    @Bean
    CommandLineRunner run(UserService userService) {
        return args -> {
            try {
                userService.createTwoUsers(
                        new User("Alice", "alice@example.com"),
                        new User("Bob", "bob@fail.com") // Will trigger rollback
                );
            } catch (Exception e) {
                System.out.println("Transaction rolled back due to: " + e.getMessage());
            }
        };
    }
}
