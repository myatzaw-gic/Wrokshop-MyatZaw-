package com.workshop.day6.no15;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserService {

    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // ✅ All operations succeed or rollback
    @Transactional(propagation = Propagation.REQUIRED)
    public void createTwoUsers(User user1, User user2) {
        userRepository.save(user1);

        // Simulate an exception to test rollback
        if (user2.getEmail().contains("fail")) {
            throw new RuntimeException("Simulated exception!");
        }

        userRepository.save(user2);
    }
}
