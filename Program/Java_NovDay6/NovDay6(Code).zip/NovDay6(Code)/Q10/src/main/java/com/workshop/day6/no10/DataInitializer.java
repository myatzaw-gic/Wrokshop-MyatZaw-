package com.workshop.day6.no10;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;

    public DataInitializer(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        // Clear existing data
        userRepository.deleteAll();

        // Initialize sample users
        List<User> users = List.of(
                new User("Alice", "alice@example.com"),
                new User("Bob", "bob@example.com"),
                new User("Charlie", "charlie@example.com"),
                new User("David", "david@example.com"),
                new User("Eve", "eve@example.com"));

        // Save all users at once
        userRepository.saveAll(users);

        System.out.println("Sample users initialized!");
    }
}
