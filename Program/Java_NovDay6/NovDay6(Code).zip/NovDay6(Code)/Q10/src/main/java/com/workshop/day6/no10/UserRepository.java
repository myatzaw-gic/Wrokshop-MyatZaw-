package com.workshop.day6.no10;

import org.springframework.data.jpa.repository.JpaRepository;

// ✅ Must extend JpaRepository or CrudRepository
public interface UserRepository extends JpaRepository<User, Long> {
}
