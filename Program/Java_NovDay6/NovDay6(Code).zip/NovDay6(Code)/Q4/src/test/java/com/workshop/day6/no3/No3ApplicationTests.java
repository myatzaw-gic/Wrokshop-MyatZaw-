package com.workshop.day6.no3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class No3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
