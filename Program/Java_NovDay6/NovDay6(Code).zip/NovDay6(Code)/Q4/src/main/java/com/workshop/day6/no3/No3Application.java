package com.workshop.day6.no3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class No3Application {

	public static void main(String[] args) {
		SpringApplication.run(No3Application.class, args);
	}

	/*
	 * GET http://localhost:8080/api/users
	 * GET http://localhost:8080/api/users/1
	 */

	/*
	 * Insert
	 * curl -X POST http://localhost:8080/api/users \
	 * -H "Content-Type: application/json" \
	 * -d '{"username":"myatzaw","email":"myatzaw@example.com"}'
	 *
	 */

	/*
	 * Update
	 * curl -X PUT http://localhost:8080/api/users/1 \
	 * -H "Content-Type: application/json" \
	 * -d '{"username":"myatzaw123","email":"myatzaw123@example.com"}'
	 * 
	 */

	/*
	 * Delete
	 * curl -X DELETE http://localhost:8080/api/users/1
	 */
}
