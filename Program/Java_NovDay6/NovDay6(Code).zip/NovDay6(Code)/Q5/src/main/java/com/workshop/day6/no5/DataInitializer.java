package com.workshop.day6.no5;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

@Component
public class DataInitializer implements CommandLineRunner {

    private final ProductRepository repository;

    public DataInitializer(ProductRepository repository) {
        this.repository = repository;
    }

    @Override
    public void run(String... args) throws Exception {
        if (repository.count() == 0) {

            // List of products
            List<Product> products = List.of(
                    createProduct("Laptop", new BigDecimal("1200.00")),
                    createProduct("Smartphone", new BigDecimal("800.00")),
                    createProduct("Headphones", new BigDecimal("150.00")),
                    createProduct("Smartwatch", new BigDecimal("200.00")),
                    createProduct("Tablet", new BigDecimal("450.00")));

            // Save all products
            repository.saveAll(products);

            System.out.println("Sample products initialized successfully.");
        }
    }

    private Product createProduct(String name, BigDecimal price) {
        Product product = new Product();
        product.setName(name);
        product.setPrice(price);
        return product;
    }
}
