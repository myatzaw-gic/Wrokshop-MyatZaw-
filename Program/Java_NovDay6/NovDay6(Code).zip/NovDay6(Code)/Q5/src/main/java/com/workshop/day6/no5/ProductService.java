package com.workshop.day6.no5;

import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.util.List;

@Service
public class ProductService {

    private final ProductRepository repository;

    public ProductService(ProductRepository repository) {
        this.repository = repository;
    }

    public List<Product> getProductsAbovePrice(BigDecimal price) {
        return repository.findByPriceGreaterThan(price);
    }

    public Product saveProduct(Product product) {
        return repository.save(product);
    }
}
