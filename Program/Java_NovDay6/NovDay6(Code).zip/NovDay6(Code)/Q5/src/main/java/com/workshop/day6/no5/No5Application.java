package com.workshop.day6.no5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class No5Application {

	public static void main(String[] args) {
		SpringApplication.run(No5Application.class, args);
	}

	// http://localhost:8080/products

}
