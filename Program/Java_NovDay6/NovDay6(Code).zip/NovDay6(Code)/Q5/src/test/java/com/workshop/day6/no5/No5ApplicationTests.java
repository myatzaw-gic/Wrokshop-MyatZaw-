package com.workshop.day6.no5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class No5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
