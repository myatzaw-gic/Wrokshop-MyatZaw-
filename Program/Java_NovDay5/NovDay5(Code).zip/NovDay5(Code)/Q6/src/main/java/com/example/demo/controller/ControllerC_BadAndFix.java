package com.example.demo.controller;

import com.example.demo.model.User;
import com.example.demo.service.UserService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
public class ControllerC_BadAndFix {

    private final UserService userService;
    public ControllerC_BadAndFix(UserService s) { this.userService = s; }


    @PostMapping("/saveC_bad")
    public String saveC_bad(@ModelAttribute("user") User user) {
        userService.save(user); // might not be reached if binding throws
        return "redirect:/userList";
    }


    @GetMapping("/form_fixed")
    public String showFixedForm(Model model) {
        model.addAttribute("user", new User());
        return "form_good";
    }

    @PostMapping("/saveC_fixed")
    public String saveC_fixed(@Valid @ModelAttribute("user") User user,
                              BindingResult br,
                              Model model) {
        if (br.hasErrors()) {
            // return to form so user corrects input (no 400 returned)
            return "form_good";
        }
        userService.save(user);
        return "redirect:/userList";
    }
}