package com.example.demo.controller;

import com.example.demo.model.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/user")
public class UserController {

    // Simulate a user database
    private static final Map<Integer, User> users = new HashMap<>();
    static {
        users.put(1, new User(1, "Alice"));
        users.put(2, new User(2, "Bob"));
    }

    // ----------------- Approach A: ModelAndView -----------------
    @GetMapping("/mv/{id}")
    public ModelAndView getUserModelAndView(@PathVariable int id) {
        User user = users.get(id);
        return user != null
                ? new ModelAndView("userView", "user", user)
                : new ModelAndView("error");
    }

    // ----------------- Approach B: String + Model -----------------
    @GetMapping("/string/{id}")
    public String getUserString(@PathVariable int id, Model model) {
        User user = users.get(id);
        if (user != null) {
            model.addAttribute("user", user);
            return "userView";
        } else {
            return "error";
        }
    }
}
