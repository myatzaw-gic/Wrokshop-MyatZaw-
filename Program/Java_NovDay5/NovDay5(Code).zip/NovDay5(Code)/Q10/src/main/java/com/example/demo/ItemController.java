package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class ItemController {

    @GetMapping("/items")
    public String getItems(Model model) {
        // Sample list of items
        List<String> items = List.of("Apple", "Banana", "Cherry", "Date");

        // Add the list to the model
        model.addAttribute("items", items);

        // Return the view name
        return "itemList";
    }
}


