package com.example.mvcviews;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcViewsApplication {
    public static void main(String[] args) {
        SpringApplication.run(MvcViewsApplication.class, args);
    }
}



//http://localhost:8080/check