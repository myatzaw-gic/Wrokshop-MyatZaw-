package com.example.mvcviews.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CheckController {

    @GetMapping("/check")
    public String checkCondition(Model model) {
        if (someCondition()) {
            model.addAttribute("msg", "Condition is TRUE");
            return "view1";
        } else {
            model.addAttribute("msg", "Condition is FALSE");
            return "view2";
        }
    }

    private boolean someCondition() {
        return Math.random() > 0.5;
    }
}
