package com.example.demo.model;

public class SearchCriteria {
    private String query;
    private int page;

    public SearchCriteria() {}

    public String getQuery() { return query; }
    public void setQuery(String query) { this.query = query; }

    public int getPage() { return page; }
    public void setPage(int page) { this.page = page; }
}