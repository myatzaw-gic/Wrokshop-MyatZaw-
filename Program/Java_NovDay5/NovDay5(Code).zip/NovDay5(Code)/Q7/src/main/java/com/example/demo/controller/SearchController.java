package com.example.demo.controller;


import com.example.demo.model.SearchCriteria;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class SearchController {

    // ----------------- Option B: Best practice -----------------
    @GetMapping("/search")
    public String searchRequestParam(@RequestParam String query, Model model) {
        model.addAttribute("method", "@RequestParam");
        model.addAttribute("query", query);
        return "searchResult";
    }

    // ----------------- Option C: Using HttpServletRequest -----------------
    @GetMapping("/search/request")
    public String searchHttpRequest(HttpServletRequest request, Model model) {
        String query = request.getParameter("query");
        model.addAttribute("method", "HttpServletRequest");
        model.addAttribute("query", query);
        return "searchResult";
    }

    // ----------------- Option D: Using @ModelAttribute -----------------
    @GetMapping("/search/model")
    public String searchModelAttribute(@ModelAttribute SearchCriteria criteria, Model model) {
        model.addAttribute("method", "@ModelAttribute");
        model.addAttribute("query", criteria.getQuery());
        model.addAttribute("page", criteria.getPage());
        return "searchResult";
    }

    // ----------------- Show search form -----------------
    @GetMapping("/searchForm")
    public String showForm(Model model) {
        model.addAttribute("searchCriteria", new SearchCriteria());
        return "searchForm";
    }
}
