package com.example.demo.controller;


import com.example.demo.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class UserControllerD {

    private final UserService userService;

    public UserControllerD(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/api/usersD")
    public ModelAndView getUsers() {
        return new ModelAndView("jsonView", "users", userService.getAllUsers());
    }
}