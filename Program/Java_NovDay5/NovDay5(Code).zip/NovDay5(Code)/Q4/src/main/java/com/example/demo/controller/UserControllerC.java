package com.example.demo.controller;


import com.example.demo.model.User;
import com.example.demo.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
public class UserControllerC {

    private final UserService userService;

    public UserControllerC(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/api/usersC")
    @ResponseBody
    public List<User> getUsers() {
        return userService.getAllUsers();
    }
}
