package com.example.demo.controller;

import com.example.demo.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class UserControllerA {

    private final UserService userService;

    public UserControllerA(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/api/usersA")
    public String getUsers(Model model) {
        model.addAttribute("users", userService.getAllUsers());
        return "userJson"; // View template required
    }
}