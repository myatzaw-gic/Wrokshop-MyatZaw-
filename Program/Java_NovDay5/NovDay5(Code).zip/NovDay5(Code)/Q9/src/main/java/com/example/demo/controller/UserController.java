package com.example.demo.controller;

import com.example.demo.model.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.HashMap;
import java.util.Map;

@Controller
public class UserController {

    // Simulated user database
    private static final Map<Long, User> users = new HashMap<>();
    static {
        users.put(1L, new User(1L, "Alice"));
        users.put(2L, new User(2L, "Bob"));
    }

    // ---------------- GET /users/{id} ----------------
    @GetMapping("/users/{id}")
    public String getUserById(@PathVariable Long id, Model model) {
        User user = users.get(id);
        if (user != null) {
            model.addAttribute("user", user);
            return "userView"; // Thymeleaf template
        } else {
            return "error"; // Error page
        }
    }
}