package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
public class UserController {

    // In-memory list of users
    private List<User> users = new ArrayList<>();

    // Show the form to add a new user
    @GetMapping("/userForm")
    public String showForm(Model model) {
        model.addAttribute("user", new User());
        return "userForm";
    }

    // Handle form submission
    @PostMapping("/update")
    public String updateUser(@ModelAttribute("user") User user) {
        // Add or update the user in the list
        users.add(user);
        return "redirect:/users";
    }

    // Display all users
    @GetMapping("/users")
    public String listUsers(Model model) {
        model.addAttribute("users", users);
        return "userList";
    }
}