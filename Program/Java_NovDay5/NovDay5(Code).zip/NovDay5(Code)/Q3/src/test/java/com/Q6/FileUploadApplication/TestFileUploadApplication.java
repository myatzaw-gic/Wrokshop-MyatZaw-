package com.Q6.FileUploadApplication;

import org.springframework.boot.SpringApplication;

public class TestFileUploadApplication {

	public static void main(String[] args) {
		SpringApplication.from(FileUploadApplication::main).with(TestcontainersConfiguration.class).run(args);
	}

}
