package com.example.registration.dto;
import jakarta.validation.constraints.*;
public class UserDto {
 @NotBlank @Size(min=3,max=30) private String username;
 @NotBlank @Size(min=8) private String password;
 @NotBlank private String confirmPassword;
 @NotBlank private String fullName;
 @NotBlank @Email private String email;
 @Pattern(regexp= "") private String phone;

 public String getUsername(){return username;} public void setUsername(String v){username=v;}
 public String getPassword(){return password;} public void setPassword(String v){password=v;}
 public String getConfirmPassword(){return confirmPassword;} public void setConfirmPassword(String v){confirmPassword=v;}
 public String getFullName(){return fullName;} public void setFullName(String v){fullName=v;}
 public String getEmail(){return email;} public void setEmail(String v){email=v;}
 public String getPhone(){return phone;} public void setPhone(String v){phone=v;}
}
