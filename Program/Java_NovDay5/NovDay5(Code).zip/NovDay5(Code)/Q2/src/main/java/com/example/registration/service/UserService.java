package com.example.registration.service;
import com.example.registration.dto.UserDto;
import org.springframework.stereotype.Service;
@Service
public class UserService {
 public void register(UserDto dto){
   System.out.println("Registering "+dto.getUsername());
 }
}
