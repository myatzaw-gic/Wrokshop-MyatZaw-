package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class FormController {

    @RequestMapping(value = "/form", method = {RequestMethod.GET, RequestMethod.POST})
    public String handleForm(
            @RequestParam(required = false) String name,
            Model model) {

        if (name != null) {
            model.addAttribute("message", "Hello, " + name + "!");
        } else {
            model.addAttribute("message", "Please enter your name and submit.");
        }

        return "formPage";
    }
}