package com.example.registration.controller;
import com.example.registration.dto.UserDto;
import com.example.registration.service.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
public class UserController {
 @Autowired private UserService userService;

 @GetMapping("/register")
 public String form(Model m){ m.addAttribute("userDto", new UserDto()); return "register"; }

 @PostMapping("/register")
 public String submit(@ModelAttribute("userDto") @Valid UserDto dto,
                      BindingResult result, Model m){
   if(!dto.getPassword().equals(dto.getConfirmPassword()))
       result.rejectValue("confirmPassword","mismatch","Passwords do not match");
   if(result.hasErrors()) return "register";
   userService.register(dto);
   m.addAttribute("successMessage","Success");
   return "register-success";
 }
}
