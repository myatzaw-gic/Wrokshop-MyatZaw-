package com.example.sessionattributesdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SessionAttributesDemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(SessionAttributesDemoApplication.class, args);
    }
}



//http://localhost:8080/user/form