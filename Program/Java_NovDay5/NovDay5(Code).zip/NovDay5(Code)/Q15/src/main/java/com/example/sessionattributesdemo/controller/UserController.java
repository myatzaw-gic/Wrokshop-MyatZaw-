package com.example.sessionattributesdemo.controller;

import com.example.sessionattributesdemo.model.UserForm;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;

@Controller
@RequestMapping("/user")
@SessionAttributes("user")
public class UserController {

    @ModelAttribute("user")
    public UserForm userForm() {
        return new UserForm();
    }

    @GetMapping("/form")
    public String showForm(Model model) {
        return "user-form";
    }

    @PostMapping("/form")
    public String submit(@ModelAttribute("user") UserForm user) {
        return "redirect:/user/confirm";
    }

    @GetMapping("/confirm")
    public String confirm(@ModelAttribute("user") UserForm user) {
        return "user-confirm";
    }

    @PostMapping("/finish")
    public String finish(SessionStatus status) {
        status.setComplete();
        return "redirect:/user/form";
    }
}
